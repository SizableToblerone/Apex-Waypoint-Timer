# Waypoint Timer

#### A graphic circular timer, currently specifically for *Apex Legends*.
##### Eventually to be converted to a more general version.
